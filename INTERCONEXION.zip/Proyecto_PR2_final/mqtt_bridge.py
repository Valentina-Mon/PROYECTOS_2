"""
Puente: Web (MQTT) -> PostgreSQL.

La pagina publica JSON en el tema tienda/pedido/nuevo; este script lo guarda en tablas
clientes, pedidos, lineas_pedido, envios y actualiza stock_sabores. Si falta stock,
publica tienda/stock/alerta y no graba nada.

Ejecutar:
  cd Proyecto_final_pr2
  python -m pip install -r requirements.txt
  copia .env.example a .env y rellena MQTT y Postgres
  python mqtt_bridge.py

Dependencias: pg8000, paho-mqtt, python-dotenv, certifi (MQTT por WSS).
"""

import hashlib
import itertools
import json
import os
import random
import re
import ssl
import string
import unicodedata
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import urlparse

import certifi
import pg8000
from dotenv import load_dotenv
from paho.mqtt import client as mqtt_client
from paho.mqtt.enums import CallbackAPIVersion

load_dotenv()

MQTT_URL = os.getenv("MQTT_URL", "")
MQTT_USERNAME = os.getenv("MQTT_USERNAME", "")
MQTT_PASSWORD = os.getenv("MQTT_PASSWORD", "")
MQTT_TOPIC = os.getenv("MQTT_TOPIC", "tienda/pedido/nuevo")
LOGISTICA_TOPIC_PREFIX = os.getenv("LOGISTICA_TOPIC_PREFIX", "logistica")
EMPRESA_REPARTO_ID = os.getenv("EMPRESA_REPARTO_ID")
# Aviso opcional para ESP32 / planta (mismo broker)
FABRICA_TOPIC = os.getenv("FABRICA_TOPIC", "fabrica/esp32/pedido_guardado")
NUMERO_COMBI_TOPIC = os.getenv("NUMERO_COMBI_TOPIC", "numero_combi")
FABRICA_NUMERO_COMBI_TOPIC = os.getenv("FABRICA_NUMERO_COMBI_TOPIC", "fabrica/numero_combi")

PGHOST = os.getenv("PGHOST", "localhost")
PGPORT = int(os.getenv("PGPORT", "5432"))
PGUSER = os.getenv("PGUSER", "postgres")
PGPASSWORD = os.getenv("PGPASSWORD", "")
PGDATABASE = os.getenv("PGDATABASE", "postgres")

SABORES_ORDENADOS = ("chocolate", "caramelo", "avellana")
SABOR_ALIAS = {
    "1": "chocolate",
    "2": "caramelo",
    "3": "avellana",
    "chocolate negro 70%": "chocolate",
    "chocolate": "chocolate",
    "caramelo salado": "caramelo",
    "caramelo": "caramelo",
    "avellana praline": "avellana",
    "avellama praline": "avellana",
    "avellana": "avellana",
}

# Numero de combinacion (1..34) segun combinaciones con repeticion de 3 sabores y tamano 1..4.
COMBINACION_A_NUMERO: Dict[Tuple[str, ...], int] = {}
NUMERO_A_COMBINACION: Dict[int, Tuple[str, ...]] = {}
for tam in range(1, 5):
    for combo in itertools.combinations_with_replacement(SABORES_ORDENADOS, tam):
        numero = len(COMBINACION_A_NUMERO) + 1
        COMBINACION_A_NUMERO[combo] = numero
        NUMERO_A_COMBINACION[numero] = combo


def comprobar_variables_mqtt() -> None:
    if not MQTT_URL or not MQTT_USERNAME or not MQTT_PASSWORD:
        raise SystemExit("Faltan MQTT_URL, MQTT_USERNAME o MQTT_PASSWORD en .env")


# --- Utilidades de texto / MQTT ---------------------------------------------

def normalizar_nombre_sabor(nombre: str) -> str:
    s = (nombre or "").lower()
    s = unicodedata.normalize("NFD", s)
    s = "".join(c for c in s if unicodedata.category(c) != "Mn")
    return s.strip()


def tipo_pedido_desde_carrito(productos: List[Any]) -> str:
    """
    Si en el carrito hay alguna linea 'industrial', el pedido es industrial.
    (La web ya limita cajas; antes se exigian >=5 cajas y con maximo 4 nunca marcaba bien.)
    """
    if not isinstance(productos, list) or not productos:
        return "personalizado"
    for item in productos:
        if isinstance(item, dict) and item.get("tipo") == "industrial":
            return "industrial"
    return "personalizado"


def _normalizar_sabor_para_combinacion(raw: Any) -> Optional[str]:
    nombre = normalizar_nombre_sabor(str(raw or ""))
    return SABOR_ALIAS.get(nombre)


def _extraer_cajas_por_sabor_industrial(productos: List[Any]) -> Dict[str, int]:
    out = {s: 0 for s in SABORES_ORDENADOS}
    if not isinstance(productos, list):
        return out
    for item in productos:
        if not isinstance(item, dict) or item.get("tipo") != "industrial":
            continue
        det = item.get("detalles")
        if not isinstance(det, dict):
            continue
        for sabor_raw, cajas_raw in det.items():
            sabor = _normalizar_sabor_para_combinacion(sabor_raw)
            if not sabor:
                continue
            cajas = int(cajas_raw) if cajas_raw is not None else 0
            if cajas > 0:
                out[sabor] += cajas
    return out


def obtener_numero_combinacion(productos: List[Any], tipo_pedido: str) -> Optional[Dict[str, Any]]:
    """
    Devuelve el numero de combinacion para pedidos industriales de 1..4 cajas.
    Se representa como multiconjunto ordenado (ej. chocolate, chocolate, caramelo).
    """
    if tipo_pedido != "industrial":
        return None
    cajas_por_sabor = _extraer_cajas_por_sabor_industrial(productos)
    total_cajas = sum(cajas_por_sabor.values())
    if total_cajas <= 0:
        return None
    if total_cajas > 4:
        # El front limita a 4. Si llega mas, no se calcula combinacion cerrada.
        return None
    combo: List[str] = []
    for sabor in SABORES_ORDENADOS:
        combo.extend([sabor] * cajas_por_sabor[sabor])
    combo_tuple = tuple(combo)
    numero = COMBINACION_A_NUMERO.get(combo_tuple)
    if not numero:
        return None
    return {
        "numero": numero,
        "tamano": total_cajas,
        "sabores": list(combo_tuple),
        "conteo": cajas_por_sabor,
    }


def asegurar_tablas_combinaciones(conn) -> None:
    """
    Crea un "arbol" persistente de combinaciones y una tabla de relacion pedido->combinacion.
    """
    cur = conn.cursor()
    try:
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS public.arbol_combinaciones (
                numero_combi integer PRIMARY KEY,
                tamano integer NOT NULL CHECK (tamano BETWEEN 1 AND 4),
                sabor_1 varchar(30) NOT NULL,
                sabor_2 varchar(30),
                sabor_3 varchar(30),
                sabor_4 varchar(30),
                ruta varchar(200) NOT NULL UNIQUE
            )
            """
        )
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS public.pedidos_combinacion (
                id_pedido integer PRIMARY KEY REFERENCES public.pedidos(id_pedido) ON DELETE CASCADE,
                numero_combi integer NOT NULL REFERENCES public.arbol_combinaciones(numero_combi),
                tamano integer NOT NULL CHECK (tamano BETWEEN 1 AND 4),
                sabores_json text NOT NULL,
                fecha_registro timestamp without time zone DEFAULT now() NOT NULL
            )
            """
        )
        cur.execute("SELECT count(*) FROM public.arbol_combinaciones")
        total = int(cur.fetchone()[0] or 0)
        if total == 0:
            for numero, combo in NUMERO_A_COMBINACION.items():
                sabores = list(combo) + [None] * (4 - len(combo))
                ruta = " > ".join(combo)
                cur.execute(
                    """
                    INSERT INTO public.arbol_combinaciones
                      (numero_combi, tamano, sabor_1, sabor_2, sabor_3, sabor_4, ruta)
                    VALUES (%s, %s, %s, %s, %s, %s, %s)
                    """,
                    (numero, len(combo), sabores[0], sabores[1], sabores[2], sabores[3], ruta),
                )
        conn.commit()
    finally:
        cur.close()


def contar_cajas_grandes(productos: List[Any]) -> int:
    if not isinstance(productos, list):
        return 1
    total = 0
    for item in productos:
        if not isinstance(item, dict):
            continue
        if item.get("tipo") == "industrial":
            det = item.get("detalles")
            if isinstance(det, dict):
                for v in det.values():
                    total += int(v) if v is not None else 0
        elif item.get("tipo") == "personalizado":
            total += int(item.get("cajas") or 0)
    return total if total > 0 else 1


def extraer_lineas_pedido(productos: List[Any]) -> List[Dict[str, Any]]:
    """
    Une todas las lineas del carrito en cantidades por nombre de sabor.
    - Industrial: detalles = cajas grandes por sabor; cada una son 48 cajitas -> multiplicamos por 48.
    - Personalizado: detalles = cajitas por sabor (factor 1).
    Las cantidades deben coincidir con lo que guardais en stock_sabores.stock_paquetes.
    """
    acumulado: Dict[str, int] = {}
    if not isinstance(productos, list):
        return []
    for item in productos:
        if not isinstance(item, dict):
            continue
        det = item.get("detalles")
        if not isinstance(det, dict):
            continue
        factor = 48 if item.get("tipo") == "industrial" else 1
        for nombre, cantidad in det.items():
            qty = (int(cantidad) if cantidad is not None else 0) * factor
            if qty <= 0:
                continue
            key = str(nombre)
            acumulado[key] = acumulado.get(key, 0) + qty
    return [{"nombre": nombre, "cantidad": cantidad} for nombre, cantidad in acumulado.items()]


def get_or_create_sabor(cur, nombre_sabor: Any) -> int:
    referencia = str(nombre_sabor or "").strip()
    if re.fullmatch(r"\d+", referencia):
        sid = int(referencia)
        cur.execute(
            "SELECT id_sabor FROM public.sabores WHERE id_sabor = %s LIMIT 1",
            (sid,),
        )
        row = cur.fetchone()
        if row:
            return row[0]
        raise ValueError(f"Sabor con id {sid} no existe en BD")

    buscado = normalizar_nombre_sabor(referencia)
    if not buscado:
        return 1

    cur.execute(
        "SELECT id_sabor FROM public.sabores WHERE lower(nombre) = %s LIMIT 1",
        (buscado,),
    )
    row = cur.fetchone()
    if row:
        return row[0]

    cur.execute(
        "INSERT INTO public.sabores (nombre, activo) VALUES (%s, true) RETURNING id_sabor",
        (str(nombre_sabor),),
    )
    return cur.fetchone()[0]


def validar_stock_disponible(cur, lineas: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    out = []
    for linea in lineas:
        id_sabor = get_or_create_sabor(cur, linea["nombre"])
        cur.execute(
            "SELECT stock_paquetes FROM public.stock_sabores WHERE id_sabor = %s LIMIT 1",
            (id_sabor,),
        )
        row = cur.fetchone()
        stock_actual = int(row[0]) if row else 0
        pedido = int(linea["cantidad"] or 0)
        if stock_actual < pedido:
            out.append(
                {
                    "idSabor": id_sabor,
                    "sabor": linea["nombre"],
                    "pedido": pedido,
                    "stock": stock_actual,
                }
            )
    return out


def descontar_stock(cur, lineas: List[Dict[str, Any]]) -> None:
    for linea in lineas:
        id_sabor = get_or_create_sabor(cur, linea["nombre"])
        cur.execute(
            """
            UPDATE public.stock_sabores
            SET stock_paquetes = stock_paquetes - %s,
                fecha_actualizacion = now()
            WHERE id_sabor = %s
            """,
            (linea["cantidad"], id_sabor),
        )


def get_or_create_cliente(cur, cliente: Dict[str, Any]) -> int:
    """
    Identifica al cliente web por un CIF sintetico WEB-xxxxx (hash de nombre+telefono+direccion).
    Si ya existe, actualiza nombre, telefono y direccion por si cambian en un pedido nuevo.
    """
    nombre = (cliente.get("nombre") or "").strip()
    telefono = (cliente.get("telefono") or "").strip()
    direccion = (cliente.get("direccion") or "").strip()
    if not nombre or not telefono or not direccion:
        raise ValueError("Datos de cliente incompletos")

    digest = hashlib.md5(f"{nombre}|{telefono}|{direccion}".encode("utf-8")).hexdigest()[:12].upper()
    cif_generado = f"WEB-{digest}"

    cur.execute(
        "SELECT id_cliente FROM public.clientes WHERE cif = %s LIMIT 1",
        (cif_generado,),
    )
    row = cur.fetchone()
    if row:
        id_cliente = row[0]
        cur.execute(
            """
            UPDATE public.clientes
            SET nombre = %s, telefono = %s, direccion = %s, nombre_empresa = %s
            WHERE id_cliente = %s
            """,
            (nombre, telefono, direccion, nombre, id_cliente),
        )
        return id_cliente

    cur.execute(
        """
        INSERT INTO public.clientes
          (tipo_cliente, nombre, cif, telefono, correo, nombre_empresa, direccion)
        VALUES
          ('empresa', %s, %s, %s, %s, %s, %s)
        RETURNING id_cliente
        """,
        (nombre, cif_generado, telefono, None, nombre, direccion),
    )
    return cur.fetchone()[0]


# --- Envios y empresa de reparto --------------------------------------------


def obtener_empresa_reparto_por_defecto(cur) -> Optional[Dict[str, Any]]:
    if EMPRESA_REPARTO_ID:
        try:
            eid = int(EMPRESA_REPARTO_ID)
        except ValueError:
            eid = None
        if eid is not None:
            cur.execute(
                """
                SELECT id_empresa_reparto, nombre FROM public.empresas_reparto
                WHERE id_empresa_reparto = %s LIMIT 1
                """,
                (eid,),
            )
            row = cur.fetchone()
            if row:
                return {"id_empresa_reparto": row[0], "nombre": row[1]}

    cur.execute(
        """
        SELECT id_empresa_reparto, nombre FROM public.empresas_reparto
        ORDER BY id_empresa_reparto LIMIT 1
        """
    )
    row = cur.fetchone()
    if row:
        return {"id_empresa_reparto": row[0], "nombre": row[1]}
    return None


def crear_envio_inicial(cur, id_pedido: int) -> Dict[str, Any]:
    empresa = obtener_empresa_reparto_por_defecto(cur)
    id_empresa = empresa["id_empresa_reparto"] if empresa else None
    cur.execute(
        """
        INSERT INTO public.envios (id_pedido, id_empresa_reparto, estado_envio)
        VALUES (%s, %s, 'pendiente')
        RETURNING id_envio
        """,
        (id_pedido, id_empresa),
    )
    id_envio = cur.fetchone()[0]
    return {
        "idEnvio": id_envio,
        "idEmpresaReparto": id_empresa,
        "nombreEmpresaReparto": empresa["nombre"] if empresa else None,
    }


# --- Procesar un pedido completo (transaccion) -------------------------------


def guardar_pedido(payload: Dict[str, Any]) -> Dict[str, Any]:
    conn = pg8000.connect(
        user=PGUSER,
        password=PGPASSWORD,
        host=PGHOST,
        port=PGPORT,
        database=PGDATABASE,
    )
    conn.autocommit = False
    cur = conn.cursor()
    try:
        cliente = payload.get("cliente") or {}
        if not isinstance(cliente, dict):
            cliente = {}
        productos = payload.get("productos") or []
        if not isinstance(productos, list):
            productos = []
        total = float(payload.get("total") or 0)
        cajas = contar_cajas_grandes(productos)
        tipo = tipo_pedido_desde_carrito(productos)
        combinacion = obtener_numero_combinacion(productos, tipo)
        nota = (cliente.get("nota") or "").strip()
        observaciones = nota if nota else "Pedido recibido por MQTT"

        # 1) Cliente (tabla clientes: nombre, telefono, direccion, cif WEB-...)
        id_cliente = get_or_create_cliente(cur, cliente)

        # 2) Lineas en unidades de stock (sabores / cantidades)
        lineas = extraer_lineas_pedido(productos)
        faltantes = validar_stock_disponible(cur, lineas)
        if faltantes:
            conn.rollback()
            return {"ok": False, "motivo": "stock", "faltantes": faltantes}

        # 3) Cabecera del pedido
        cur.execute(
            """
            INSERT INTO public.pedidos
              (id_cliente, tipo_pedido, cantidad_cajas_grandes, estado_pedido, precio_total, observaciones)
            VALUES
              (%s, %s, %s, 'pendiente', %s, %s)
            RETURNING id_pedido
            """,
            (id_cliente, tipo, cajas, total, observaciones),
        )
        id_pedido = cur.fetchone()[0]

        # 4) Envio inicial y empresa de reparto (tabla envios)
        envio = crear_envio_inicial(cur, id_pedido)

        # 5) Bajar stock antes de insertar lineas (misma transaccion)
        descontar_stock(cur, lineas)

        # 6) Detalle por sabor (tabla lineas_pedido)
        for linea in lineas:
            id_sabor = get_or_create_sabor(cur, linea["nombre"])
            cur.execute(
                """
                INSERT INTO public.lineas_pedido (id_pedido, id_sabor, cantidad_paquetes)
                VALUES (%s, %s, %s)
                """,
                (id_pedido, id_sabor, linea["cantidad"]),
            )

        if combinacion:
            cur.execute(
                """
                INSERT INTO public.pedidos_combinacion
                  (id_pedido, numero_combi, tamano, sabores_json)
                VALUES (%s, %s, %s, %s)
                ON CONFLICT (id_pedido) DO UPDATE
                SET numero_combi = EXCLUDED.numero_combi,
                    tamano = EXCLUDED.tamano,
                    sabores_json = EXCLUDED.sabores_json
                """,
                (
                    id_pedido,
                    combinacion["numero"],
                    combinacion["tamano"],
                    json.dumps(combinacion["sabores"], ensure_ascii=False),
                ),
            )

        conn.commit()
        return {
            "ok": True,
            "idPedido": id_pedido,
            "envio": envio,
            "lineas": lineas,
            "combinacion": combinacion,
        }
    except Exception:
        conn.rollback()
        raise
    finally:
        cur.close()
        conn.close()


def parse_mqtt_url(url: str) -> Tuple[str, int, str, bool, bool]:
    u = urlparse(url)
    host = u.hostname or ""
    if not host:
        raise ValueError("URL MQTT sin host")
    scheme = (u.scheme or "mqtt").lower()
    port = u.port
    if port is None:
        if scheme in ("wss", "https"):
            port = 443
        elif scheme in ("mqtts", "ssl"):
            port = 8883
        elif scheme in ("ws", "http"):
            port = 80
        else:
            port = 1883
    path = u.path or "/mqtt"
    if not path.startswith("/"):
        path = "/" + path
    use_ws = scheme in ("ws", "wss", "http", "https")
    use_tls = scheme in ("mqtts", "wss", "https", "ssl")
    return host, port, path, use_ws, use_tls


def on_connect(client: mqtt_client.Client, userdata: Any, flags: Any, reason_code: Any, properties: Any = None) -> None:
    if getattr(reason_code, "is_failure", False):
        print(f"MQTT error conexion: {reason_code}")
        return
    print(f"MQTT OK. Suscrito a {MQTT_TOPIC}")
    client.subscribe(MQTT_TOPIC, qos=1)


def on_message(client: mqtt_client.Client, userdata: Any, msg: mqtt_client.MQTTMessage) -> None:
    raw = msg.payload.decode("utf-8", errors="replace")
    topic = msg.topic
    try:
        payload = json.loads(raw)
        resultado = guardar_pedido(payload)
        if not resultado.get("ok"):
            client.publish(
                "tienda/stock/alerta",
                json.dumps(
                    {
                        "estado": "rechazado_sin_stock",
                        "faltantes": resultado.get("faltantes"),
                        "mensaje": "No hay stock suficiente para uno o varios sabores. Proveedores en camino.",
                    },
                    ensure_ascii=False,
                ),
                qos=1,
            )
            print("Pedido rechazado por falta de stock")
            return

        e = resultado["envio"]
        idp = resultado["idPedido"]
        client.publish(
            "tienda/pedido/confirmado",
            json.dumps(
                {
                    "estado": "confirmado",
                    "idPedido": idp,
                    "idEnvio": e["idEnvio"],
                    "empresaReparto": e["nombreEmpresaReparto"],
                    "mensaje": "Pedido guardado correctamente.",
                },
                ensure_ascii=False,
            ),
            qos=1,
        )
        client.publish(
            f"{LOGISTICA_TOPIC_PREFIX}/envio/asignado",
            json.dumps(
                {
                    "idPedido": idp,
                    "idEnvio": e["idEnvio"],
                    "idEmpresaReparto": e["idEmpresaReparto"],
                    "empresaReparto": e["nombreEmpresaReparto"],
                    "estadoEnvio": "pendiente",
                },
                ensure_ascii=False,
            ),
            qos=1,
        )
        client.publish(
            f"{LOGISTICA_TOPIC_PREFIX}/pedido/{idp}/envio",
            json.dumps(
                {
                    "idPedido": idp,
                    "idEnvio": e["idEnvio"],
                    "empresaReparto": e["nombreEmpresaReparto"],
                    "mensaje": "Empresa de reparto asignada.",
                },
                ensure_ascii=False,
            ),
            qos=1,
        )
        # Mensaje corto para ESP32 / PLC: mismo broker
        client.publish(
            FABRICA_TOPIC,
            json.dumps(
                {
                    "evento": "pedido_guardado",
                    "idPedido": idp,
                    "idEnvio": e["idEnvio"],
                    "lineas": resultado.get("lineas", []),
                    "numeroCombi": (resultado.get("combinacion") or {}).get("numero"),
                },
                ensure_ascii=False,
            ),
            qos=1,
        )
        combinacion = resultado.get("combinacion")
        if combinacion:
            client.publish(
                NUMERO_COMBI_TOPIC,
                json.dumps(
                    {
                        "idPedido": idp,
                        "numeroCombi": combinacion["numero"],
                        "tamano": combinacion["tamano"],
                        "sabores": combinacion["sabores"],
                        "conteo": combinacion["conteo"],
                    },
                    ensure_ascii=False,
                ),
                qos=1,
            )
            client.publish(
                FABRICA_NUMERO_COMBI_TOPIC,
                json.dumps(
                    {
                        "evento": "numero_combi",
                        "idPedido": idp,
                        "numeroCombi": combinacion["numero"],
                        "tamano": combinacion["tamano"],
                        "sabores": combinacion["sabores"],
                        "conteo": combinacion["conteo"],
                    },
                    ensure_ascii=False,
                ),
                qos=1,
            )
        print(f"Pedido {idp} guardado (topic entrada {topic})")
    except Exception as ex:
        print("Error procesando MQTT:", ex)
        print("Payload:", raw)


def main() -> None:
    comprobar_variables_mqtt()
    conn = pg8000.connect(
        user=PGUSER,
        password=PGPASSWORD,
        host=PGHOST,
        port=PGPORT,
        database=PGDATABASE,
    )
    asegurar_tablas_combinaciones(conn)
    conn.close()
    print("DB conectada")

    host, port, path, use_ws, use_tls = parse_mqtt_url(MQTT_URL)
    cid = "db_bridge_py_" + "".join(random.choices(string.ascii_lowercase + string.digits, k=8))
    cli = mqtt_client.Client(
        callback_api_version=CallbackAPIVersion.VERSION2,
        client_id=cid,
        transport="websockets" if use_ws else "tcp",
    )
    if use_ws:
        cli.ws_set_options(path=path)
    if use_tls:
        cli.tls_set(ca_certs=certifi.where(), cert_reqs=ssl.CERT_REQUIRED)

    cli.username_pw_set(MQTT_USERNAME, MQTT_PASSWORD)
    cli.on_connect = on_connect
    cli.on_message = on_message
    print(f"Conectando MQTT a {host}:{port} ...")
    cli.connect(host, port, keepalive=60)
    cli.loop_forever()


if __name__ == "__main__":
    main()
